This project is finished by Jiajun Deng and Zhouxiang Wu in GCS Hackthon on 10/21/2018.

Idea: This website Smart Airport focuses on precise prediction of the International arriving passengers' population at an airport.

Theory: We adopted the Malkov Queuing Theroy as our algorithm basis.

Structure of the website:
1. Index page to show two different menu for passengers and managers.
2. Login in page of managers.
3. Passengers function page and subpages.
4. Manger function page.
5. Quick show of passengers population in diagrams.

Other records:
1. Based on bootstrap, css+html+js.
2. Database built by ourselves, with simple sql syntaxes.
3. Java methods created by ourselves, to implement all important functions.
4. Link everything together by Wu.

1/9/18
by Jiajun Deng

